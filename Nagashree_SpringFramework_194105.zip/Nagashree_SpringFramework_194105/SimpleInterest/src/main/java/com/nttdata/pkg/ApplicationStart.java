package com.nttdata.pkg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationStart {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Beans.xml");
		
		Interest interest=(Interest) applicationContext.getBean("interest");
		System.out.println("Simple Interest is: "+interest.caclutateInterest());

	}

}
