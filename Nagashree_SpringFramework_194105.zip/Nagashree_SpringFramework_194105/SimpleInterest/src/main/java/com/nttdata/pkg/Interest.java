package com.nttdata.pkg;

public class Interest {

	private double principle;
	private float time;
	private float rate;
	
	
	public Interest(double principle, float time, float rate) {
		super();
		this.principle = principle;
		this.time = time;
		this.rate = rate;
	}
	
	public double caclutateInterest(){
		
		return (principle*time*rate)/100;
	}
	
	
	
}
