package webgroup.iihtspringproj;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

	@RequestMapping(value="/students", method= RequestMethod.GET,headers="Accept=application/json")
	public List getStudents(){
		List listOfStudents=new ArrayList();
		listOfStudents=createStudentList();
		return listOfStudents;
	}
	
	@RequestMapping(value = "/student/{id}", method = RequestMethod.GET,headers="Accept=application/json")
	public Students getCountryById(@PathVariable int id)
	{
		List<Students> listOfStudents = new ArrayList();
		listOfStudents=createStudentList();
 
		for (Students student: listOfStudents) {
			if(student.getStudentId()==id)
				return student;
		}
 
		return null;
	}
	
	public List createStudentList(){
		Students student=new Students(1,"Anu","JAVA");
		Students student1=new Students(2,"Nagu","PYTHON");
		List listOfStudents=new ArrayList();
		listOfStudents.add(student);
		listOfStudents.add(student1);
		return listOfStudents;
	}
}
