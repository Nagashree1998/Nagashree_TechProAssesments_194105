package com.nttdata.pkg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationStart {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Beans.xml");
		Employee employee=(Employee) applicationContext.getBean("emp");
		System.out.println("Employee ID : "+employee.getEmployeeId()+"\nEmployee Name : "+employee.getEmployeeName()+
				"\nEmployee Age :  "+employee.getEmployeeAge()+"\nEmployee Salary:  "+employee.getEmployeeSalary()+
				"\nEmployee Address : "+employee.getAddress());

	}

}
