package com.nttdata.SecureApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
