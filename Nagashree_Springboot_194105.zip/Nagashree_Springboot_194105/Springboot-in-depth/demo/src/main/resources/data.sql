insert into course(id,name,created_date,last_update_date,is_deleted) values(10001,'JPA Course',sysdate(),sysdate(),false);
insert into course(id,name,created_date,last_update_date,is_deleted) values(10002,'JAVA Course',sysdate(),sysdate(),false);
insert into course(id,name,created_date,last_update_date,is_deleted) values(10003,'SPRING Course',sysdate(),sysdate(),false);
insert into course(id,name,created_date,last_update_date,is_deleted) values(10004,'SQL Course',sysdate(),sysdate(),false);

insert into passport(id,number) values(30001,'N265SAJH');
insert into passport(id,number) values(30002,'EUR263SD');
insert into passport(id,number) values(30003,'IR3874JD');
insert into passport(id,number) values(30004,'KER7324GH');


insert into student(id,name,passport_id) values(20001,'charan',30001);
insert into student(id,name,passport_id) values(20002,'sathvik',30002);
insert into student(id,name,passport_id) values(20003,'Anu',30003);
insert into student(id,name,passport_id) values(20004,'suni',30004);



insert into review(id,description,rating,course_id) values(40001,'FOUR','Good Course',10001);
insert into review(id,description,rating,course_id) values(40002,'THREE','Better Course',10001);
insert into review(id,description,rating,course_id) values(40003,'FIVE','Best Course',10002);
insert into review(id,description,rating,course_id) values(40004,'THREE','Better Course',10003);

insert into student_course(student_id,course_id)
values(20001,10001);
insert into student_course(student_id,course_id)
values(20002,10001);
insert into student_course(student_id,course_id)
values(20003,10001);
insert into student_course(student_id,course_id)
values(20001,10003);
