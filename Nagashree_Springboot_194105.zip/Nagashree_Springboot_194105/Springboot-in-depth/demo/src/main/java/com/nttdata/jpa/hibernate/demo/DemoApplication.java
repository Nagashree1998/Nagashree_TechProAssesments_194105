package com.nttdata.jpa.hibernate.demo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nttdata.jpa.hibernate.demo.entity.Course;
import com.nttdata.jpa.hibernate.demo.entity.FullTimeEmployee;
import com.nttdata.jpa.hibernate.demo.entity.PartTimeEmployee;
import com.nttdata.jpa.hibernate.demo.entity.Review;
import com.nttdata.jpa.hibernate.demo.entity.Student;
import com.nttdata.jpa.hibernate.demo.repository.CourseRepository;
import com.nttdata.jpa.hibernate.demo.repository.EmployeeRepository;
import com.nttdata.jpa.hibernate.demo.repository.StudentRepository;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CourseRepository courseRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private EmployeeRepository employeeRepository;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//Course course = repository.findById(10001L);
		
		//logger.info("Course 10001 -> {}", course);
		//repository.save(new Course("Microservices in 100 Steps"));
		//repository.deleteById(10001L);
		
		//repository.playWithEntityManager();
		//studentRepository.saveStudentWithPassport();
		//courseRepository.addReviewsForCourse();
		
		//List<Review> reviews = new ArrayList<>();
		
		//reviews.add(new Review("Great Hands-on Stuff.","5"));	
		//reviews.add(new Review("Hatsoff.","5"));

		//courseRepository.addReviewsForCourse(10003L, reviews );		
		//studentRepository.insertStudentAndCourse(new Student("Jack"), new Course("Microservices in 100 Steps"));
		
		/*employeeRepository.insert(new PartTimeEmployee("Jill", new BigDecimal("50")));
		employeeRepository.insert(new FullTimeEmployee("Jack", new BigDecimal("10000")));

		logger.info("Full Time Employees -> {}", 
				employeeRepository.retrieveAllFullTimeEmployees());
		
		logger.info("Part Time Employees -> {}", 
				employeeRepository.retrieveAllPartTimeEmployees());*/
		
	}

}
