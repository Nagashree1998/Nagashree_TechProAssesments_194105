package com.nttdata.jpa.hibernate.demo.entity;

public enum ReviewRating {

	ZERO, ONE, TWO, THREE, FOUR, FIVE
}
