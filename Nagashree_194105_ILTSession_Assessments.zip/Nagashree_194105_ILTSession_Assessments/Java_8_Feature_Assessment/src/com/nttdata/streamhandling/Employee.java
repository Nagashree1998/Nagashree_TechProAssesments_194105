package com.nttdata.streamhandling;

public class Employee {

	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	private int employeeAge;
	
	public Employee(int employeeId, String employeeName, double employeeSalary, int employeeAge) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		this.employeeAge = employeeAge;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public int getEmployeeAge() {
		return employeeAge;
	}

	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

	@Override
	public String toString() {
		return " EmployeeId=" + employeeId + ", EmployeeName=" + employeeName + ", EmployeeSalary="
				+ employeeSalary + ", EmployeeAge=" + employeeAge + "]\n";
	}
	
	
}
