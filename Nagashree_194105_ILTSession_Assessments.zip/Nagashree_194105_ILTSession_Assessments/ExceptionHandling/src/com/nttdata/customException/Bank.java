package com.nttdata.customException;

public class Bank {

	
	void transferfunds(User u1,User u2,double amount) throws Insufficientamount
	{
		if(u1.getAccount().getAmount()<amount)
		{
			throw new Insufficientamount("you have no ammount");
		}
		else
		{
			
			double u1amt=	u1.getAccount().getAmount();
			u1.getAccount().setAmount(u1amt-amount);
			double u2amt= u2.getAccount().getAmount();
			u2.getAccount().setAmount(amount+u2amt);
			
		}
	}
}
