package com.nttdata.customException;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws Insufficientamount {
		
		Scanner scanner=new Scanner(System.in);
		int choice = 0;
		Account account1=null,account2=null;
		User user1 = null,user2=null;
		System.out.println("Welcome to Bank Application.....!!!!!!!");
		System.out.println("1. Create Account\t2.Transfer Amount\t3.Quit");
		choice=scanner.nextInt();
		do{
			
			
			switch(choice)
			{
			case 1: System.out.println("-------------Create Minimum Two Accounts--------------");
					System.out.println("1.To Create Account\t2. To repeat account Creation\t3. Quit");
					int choice1=scanner.nextInt();
					switch(choice1)
					{
					case 1: System.out.println("---------------Creating your Account---------------\n");
							System.out.println("Enter Account Holder Name");
							String accName1=scanner.next();
							System.out.println("Enter Account Id");
							int accountId1=scanner.nextInt();
							System.out.println("Enter depositing Amount");
							double amount1=scanner.nextDouble();
							account1=new Account(accountId1,amount1);
							user1=new User(accName1,account1);
							System.out.println("Account Created Successfully\n");
							
							break;
							
					case 2: System.out.println("---------------Creating your Account-----------------\n");
							System.out.println("Enter Account Holder Name");
							String accName2=scanner.next();
							System.out.println("Enter Account Id");
							int accountId2=scanner.nextInt();
							System.out.println("Enter depositing Amount");
							double amount2=scanner.nextDouble();
							account2=new Account(accountId2,amount2);
							user2=new User(accName2,account2);
							System.out.println("Account Created Successfully\n");
							break;
					case 3:System.out.println("Thank you");
							break;
							
							
					}
					break;
				
			case 2 :System.out.println("To Trasfer Fund");
				
					System.out.println("User1 : "+user1.getUsername()+"  Account Id: "+ user1.getAccount().getAccountId()+"  Amount :"+user1.getAccount().getAmount());
					System.out.println("User1 : "+user2.getUsername()+"  Account Id: "+ user2.getAccount().getAccountId()+"  Amount :"+user2.getAccount().getAmount());
					System.out.println("\nPress 1. Trasfer from User 1 to User 2\t 2. Trasfer from User 2 to User 1\t3. Quit");
					int ch=scanner.nextInt();
					try{
					switch(ch)
					{
					case 1 : Bank bank1= new Bank();
							 System.out.println("Enter the amout need to be trasfer");
							 double fund1=scanner.nextDouble();
							 bank1.transferfunds(user1, user2, fund1);
							 System.out.println("Amount transffered Successfully");
							 System.out.println("___________________________________");
							 System.out.println("Current Balance is:");
							 System.out.println("User1 : "+user1.getUsername()+"  Account Id: "+ user1.getAccount().getAccountId()+"  Amount :"+user1.getAccount().getAmount());
							 System.out.println("User1 : "+user2.getUsername()+"  Account Id: "+ user2.getAccount().getAccountId()+"  Amount :"+user2.getAccount().getAmount());
							 break;
					
					case 2 : Bank bank2= new Bank();
					 		 System.out.println("Enter the amout need to be trasfer");
					 		 double fund2=scanner.nextDouble();
					 		 bank2.transferfunds(user2, user1, fund2);
					 		 System.out.println("Amount transffered Successfully");
					 		 System.out.println("___________________________________");
					 		 System.out.println("Current Balance is:");
					 		 System.out.println("User1 : "+user1.getUsername()+"  Account Id: "+ user1.getAccount().getAccountId()+"  Amount :"+user1.getAccount().getAmount());
					 		 System.out.println("User1 : "+user2.getUsername()+"  Account Id: "+ user2.getAccount().getAccountId()+"  Amount :"+user2.getAccount().getAmount());
					 		 break;
							 
					}
					}catch(Insufficientamount e)
					{
						e.printStackTrace();
					}
			
			}
		
			
			System.out.println("\nWelcome to Bank Application.....!!!!!!!");
			System.out.println("1. Create Account\t2.Transfer Amount\t3.Quit");
			choice=scanner.nextInt();
		}while(choice!=0);
		
		scanner.close();

	}

}
