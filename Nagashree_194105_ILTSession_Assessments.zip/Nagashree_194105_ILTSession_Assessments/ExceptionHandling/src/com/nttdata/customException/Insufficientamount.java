package com.nttdata.customException;

public class Insufficientamount extends Exception {
	public Insufficientamount(String message)
	{
		System.out.println("Exception");
	}
}
