package com.nttdata.DaoImpl;

import java.util.List;

import com.nttdata.Dao.EmployeeDao;
import com.nttdata.Model.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public Employee getEmployeeById(int id) {
		
		return null;
	}

	@Override
	public Employee createEmployee() {
	
		return null;
	}

	@Override
	public Employee deleteEmployee(int id) {
		
		return null;
	}

	@Override
	public List<Employee> list() {
		
		return null;
	}

	@Override
	public Employee searchEmployeeByName(String name) {
		
		return null;
	}

}
