package com.nttdata.interfacesp;

public class WinampMediaPlayer implements AudioMediaPlayer{

	@Override
	public void playAudio() {
		System.out.println("Playing Audio in Winamp.....!!!!");
		
	}

}
