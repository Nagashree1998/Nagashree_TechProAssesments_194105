package com.nttdata.interfacesp;



public class DivMediaPlayer implements VideoMediaPlayer, AudioMediaPlayer{

	@Override
	public void playAudio() {
		System.out.println("Playing Audio in Div....!!!!!");
		
	}

	@Override
	public void playVideo() {
		System.out.println("Playing Video in Div......!!!!!");
		
	}

}
