package com.nttdata.interfacesp;

public interface VideoMediaPlayer {

	 public void playVideo();
}
