package com.nttdata.interfacesp;

public interface AudioMediaPlayer {

	public void playAudio();
}
