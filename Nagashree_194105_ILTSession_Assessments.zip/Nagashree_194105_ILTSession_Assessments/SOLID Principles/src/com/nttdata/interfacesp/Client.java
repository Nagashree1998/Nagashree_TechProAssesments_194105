package com.nttdata.interfacesp;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Select the type of media player...!!!");
		System.out.println("1.DivMediaPlayer\n2.VLCMediaPlayer\n3.WinampMediaPlayer");
		int choice=scanner.nextInt();
		switch(choice)
		{
		case 1: DivMediaPlayer div=new DivMediaPlayer();
				div.playAudio();
				div.playVideo();
				break;
				
		case 2:VlcMediaPlayer vlc=new VlcMediaPlayer();
				vlc.playAudio();
				vlc.playVideo();
				break;
		case 3:WinampMediaPlayer win=new WinampMediaPlayer();
				win.playAudio();
		case 4:System.exit(0);
		
		
		}

	}

}
