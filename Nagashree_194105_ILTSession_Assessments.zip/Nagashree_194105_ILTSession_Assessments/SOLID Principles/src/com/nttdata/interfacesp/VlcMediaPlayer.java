package com.nttdata.interfacesp;




public class VlcMediaPlayer implements VideoMediaPlayer, AudioMediaPlayer {

	@Override
	public void playAudio() {
		System.out.println("Playing Audio in VLC.......!!!!");
		
	}

	@Override
	public void playVideo() {
		
		System.out.println("Playing Video in VLC......!!!!!");
	}

}
