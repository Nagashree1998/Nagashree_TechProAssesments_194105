package com.nttdata.opencp;

public interface Shape {

	public double calculateArea();
}
