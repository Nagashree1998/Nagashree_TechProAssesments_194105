package com.nttdata.opencp;

public class Client {

	public static void main(String[] args) {

		Circle circle =new Circle();
		circle.setRadius(20);
		double area=circle.calculateArea();
		System.out.println("Area of Circle "+area);
		
		Rectangle rect=new Rectangle();
		rect.setLength(10);
		rect.setWidth(30);
		double arearect=rect.calculateArea();
		System.out.println("Area of Rectangle "+arearect);
		

	}

}
