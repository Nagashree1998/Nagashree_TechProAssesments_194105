package com.nttdata.singlerp;

public class Register implements EmployeeDetails{

	@Override
	public void RegisterDetails(Employee employee) {
		MailRequest mail=new MailRequest();
		mail.SendRequest(employee);
		
		
	}

	

}
