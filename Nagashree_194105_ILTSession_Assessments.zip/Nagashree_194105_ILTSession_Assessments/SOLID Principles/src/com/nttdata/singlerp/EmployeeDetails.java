package com.nttdata.singlerp;

public interface EmployeeDetails {
	public void RegisterDetails(Employee employee);
}
