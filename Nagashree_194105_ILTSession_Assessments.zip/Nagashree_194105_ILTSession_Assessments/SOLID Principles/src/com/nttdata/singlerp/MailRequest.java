package com.nttdata.singlerp;

public class MailRequest implements RequestDetails {

	@Override
	public void SendRequest(Employee employee) {
		String mail=employee.getEmployeeEmail();
		System.out.println("Request Sent to "+mail);
		
		
	}

}
