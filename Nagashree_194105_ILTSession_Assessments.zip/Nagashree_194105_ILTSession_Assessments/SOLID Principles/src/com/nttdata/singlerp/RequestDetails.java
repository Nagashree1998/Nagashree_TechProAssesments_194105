package com.nttdata.singlerp;

public interface RequestDetails {

	public void SendRequest(Employee employee);
}
