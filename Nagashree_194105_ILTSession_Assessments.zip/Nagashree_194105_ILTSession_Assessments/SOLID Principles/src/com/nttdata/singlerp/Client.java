package com.nttdata.singlerp;

import java.util.Scanner;

public class Client {
 public static void main(String[] args) {
	 
	Register register=new Register();
	Employee employee=new Employee();
	
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter Employee Id");
	int empId=scanner.nextInt();
	System.out.println("Enter Employee name");
	String empName=scanner.next();
	System.out.println("Enter email address");
	String empEmai=scanner.next();
	
	
	employee.setEmployeeId(empId);
	employee.setEmployeeName(empName);
	employee.setEmployeeEmail(empEmai);
	register.RegisterDetails(employee);
	
	scanner.close();
	
	
	
}
}
