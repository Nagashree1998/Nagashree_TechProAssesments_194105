package com.nttdata.liskovsp;

public class AnnualMember extends Member{

	
	public AnnualMember(String name)
	{
		super();
		this.name=name;
	}
	@Override
	public void makeBooking() {
		System.out.println("Booking is done");
		
	}

	@Override
	public void addToDatabase() {
		System.out.println(name+" details added to the database");
		
	}
}
