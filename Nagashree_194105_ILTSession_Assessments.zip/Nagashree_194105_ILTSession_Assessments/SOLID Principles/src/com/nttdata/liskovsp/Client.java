package com.nttdata.liskovsp;

import java.util.ArrayList;
import java.util.List;

public class Client {

	public static void main(String[] args) {
		List <IDatabase> myList=new ArrayList <IDatabase>();
		myList.add(new LifeTimeMember("Nagashree"));
		myList.add(new LifeTimeMember("Manisha"));
		myList.add(new Enquiry("Sam"));
		
		for(IDatabase c:myList)
			c.addToDatabase();

	}

}
