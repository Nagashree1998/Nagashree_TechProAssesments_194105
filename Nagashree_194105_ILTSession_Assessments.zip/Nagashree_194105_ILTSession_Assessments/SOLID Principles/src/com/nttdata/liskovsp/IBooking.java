package com.nttdata.liskovsp;

public interface IBooking {

	public void makeBooking();
}
