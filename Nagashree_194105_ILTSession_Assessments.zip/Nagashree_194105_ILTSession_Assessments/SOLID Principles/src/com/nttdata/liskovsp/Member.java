package com.nttdata.liskovsp;

public abstract class Member implements IDatabase,IBooking{
	
	String name;
	String memberType;
	
	public Member()
	{
		this.name=name;
	}
	public abstract void addToDatabase();
	public abstract void makeBooking();

}
