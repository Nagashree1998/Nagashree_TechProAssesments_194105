package com.nttdata.liskovsp;

public class Enquiry implements IDatabase{
	
	private String name;
	
	public Enquiry(String name)
	{
		super();
		this.name=name;
	}
	@Override
	public void addToDatabase() {
		
		System.out.println("Enqiry details Added to the database");
	}

}
