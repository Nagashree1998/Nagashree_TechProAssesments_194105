package com.nttdata.liskovsp;

public interface IDatabase {

	public void addToDatabase();
}
