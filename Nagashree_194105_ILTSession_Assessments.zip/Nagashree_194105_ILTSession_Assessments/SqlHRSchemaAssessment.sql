select * from hr.jobs where min_salary>10000;

select first_name,hire_date from hr.employees where to_char(hire_date,'yyyy') between 2002 and 2005;

select first_name,hire_date, job_id from hr.employees where job_id in ('IT_PROG','SA_MAN');

select * from hr.employees where hire_date>'01-jan-2008';

select to_char(hire_date,'mm'),count(*) from hr.employees where to_char(hire_date,'yyyy')=to_char(sysdate,'yyyy')group by to_char(hire_date,'mm');

 select job_id,AVG(salary) from hr.employees group by job_id having avg(salary)>10000;

// select job_id,AVG(MIN_SALARY+MAX_SALARY)/2 as avg_sal from hr.jobs group by job_id having avg(min_salary+max_salary)/2 > 10000;

update hr.employees SET salary=8000 where employee_id=115 and salary<10000;

select distinct d.department_id, d.department_name from hr.employees e join hr.departments d on( d.department_id=e.department_id )and e.employee_id in(select manager_id from hr.employees group by (department_id,manager_id) having count(*)>5);

select * from hr.departments where manager_id in (select employee_id from hr.employees where last_name='smith');

select first_name,job_title,start_date,end_date from hr.job_history h join jobs j on (h.job_id=j.job_id) join hr.employees e on (h.employee_id=e.employee_id) where commission_pct is null;
