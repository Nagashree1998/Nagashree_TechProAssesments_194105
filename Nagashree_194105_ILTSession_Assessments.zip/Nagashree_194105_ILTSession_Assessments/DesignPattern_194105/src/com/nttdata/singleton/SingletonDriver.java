package com.nttdata.singleton;

import java.io.IOException;
import java.io.BufferedReader;  
import java.io.InputStreamReader;  

public class SingletonDriver {

	static int count=1;  
   
    public static void main(String[] args) throws IOException {  
          
        Singleton jdbc= Singleton.getInstance();  
          
          
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
        System.out.print("Enter the username: ");  
        String username=br.readLine();  
        System.out.print("Enter the password: ");  
        String password=br.readLine();  
                      
         try {  
                  int i= jdbc.insert(username, password);  
                  if (i>0) {  
                	  count++;
                      System.out.println(count + " Data has been inserted successfully");  
                     }else{  
                          System.out.println("Data has not been inserted ");      
                       }  
                          
              } catch (Exception e) {  
                          System.out.println(e);  
                        }  
                       
                   }

}
