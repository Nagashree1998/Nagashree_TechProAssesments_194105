package com.nttdata.factory;

public interface ElectricDevice {
	void details();
}
