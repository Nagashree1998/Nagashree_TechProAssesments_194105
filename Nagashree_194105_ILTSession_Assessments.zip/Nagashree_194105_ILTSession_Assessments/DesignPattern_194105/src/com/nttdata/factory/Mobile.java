package com.nttdata.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Mobile implements ElectricDevice{
	public void details() {
		int price;
		String name;
		String type;
		
		
		String JdbcURL = "jdbc:mysql://localhost:3306/factory";
	      String Username = "root";
	      String password = "root@1234";
	      Connection con = null;
	      PreparedStatement pstmt = null;
	      ResultSet rst = null;
	      String myQuery = "select * from electronicdevice where dtype='MOBILE'";
	      try {
	         con = DriverManager.getConnection(JdbcURL, Username, password);
	         pstmt = con.prepareStatement(myQuery);
	         rst = pstmt.executeQuery();
	         System.out.println("Name\t\tPrice\t\tDevice");
	         System.out.println("----------------------------------------");
	         while(rst.next()) {
	            System.out.print(rst.getString(1));
	            System.out.print("\t\t"+rst.getInt(2));
	            System.out.print("\t\t"+rst.getString(3));
	            System.out.println();
	         }
	      } catch(Exception exec) {
	         exec.printStackTrace();
	      }
		
		
	}
}
