package com.nttdata;

import java.util.List;

public class Category {

	private String categoryName;
	private List<Book> list;
	
	
	public String getCategoryName() {
		return categoryName;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public List<Book> getList() {
		return list;
	}


	public void setList(List<Book> list) {
		this.list = list;
	}


	void show()
	{
		System.out.println("Category Name : "+categoryName);
		System.out.println(list);
	}
	
	
}
