package com.nttdata;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		Resource res=new ClassPathResource("SpringConfig.xml");
		
		BeanFactory factory=new XmlBeanFactory(res);
		Object o=(Object) factory.getBean("cat");
		
		Category category=(Category)o;
		List <Book> list=new ArrayList <Book>();
		Scanner scanner =new Scanner(System.in);
		System.out.println("------------Spring Core-------------");
		System.out.println("Enter Category Name");
		String categoryName=scanner.next();
		category.setCategoryName(categoryName);
		System.out.println("Enter Number of Books need to be insert");
		int num=scanner.nextInt();
		int bookId;
		String bookName;
		Double bookPrice;
		for(int i=1;i<=num;i++)
		{
			BeanFactory factory1=new XmlBeanFactory(res);
			Object o1=factory1.getBean("bk");
			Book book=(Book)o1;
			System.out.println("Enter ID of Book "+i);
			bookId=scanner.nextInt();
			book.setBookId(bookId);
			System.out.println("Enter Name of Book "+i);
			bookName=scanner.next();
			book.setBookName(bookName);
			System.out.println("Enter Price of Book "+i);
			bookPrice=scanner.nextDouble();
			book.setBookPrice(bookPrice);
			list.add(book);
		}
		category.setList(list);
		category.show();
		
	}

}
