package com.nttdata.simulation;

public class Car extends Vehicle{
	
	private String carNumber;
	private String carName;
	private double carPrice;
	private String carColor;
	private int maximumSpeed;


	public Engine getEngine() {
		return engine;
	}


	public void setEngine(Engine engine) {
		this.engine = engine;
	}


	public String getCarNumber() {
		return carNumber;
	}


	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}


	public String getCarName() {
		return carName;
	}


	public void setCarName(String carName) {
		this.carName = carName;
	}


	public double getCarPrice() {
		return carPrice;
	}


	public void setCarPrice(double carPrice) {
		this.carPrice = carPrice;
	}



	public String getCarColor() {
		return carColor;
	}


	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}



	public int getMaximumSpeed() {
		return maximumSpeed;
	}


	public void setMaximumSpeed(int maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}


	public Car(String carNumber, String carName, double carPrice, String carColor, int maximumSpeed) {
		super();
		this.carNumber = carNumber;
		this.carName = carName;
		this.carPrice = carPrice;
		this.carColor = carColor;
		this.maximumSpeed = maximumSpeed;
	}

	void display() {
		System.out.println("Car Number: "+carNumber+"\nCar Name: "+carName+"\nCar Price: "+carPrice+"\nCar Color: "+carColor+"\nMaximum Speed :"+maximumSpeed);
		
	}
	
	

}
