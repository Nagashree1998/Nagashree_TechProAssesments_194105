package com.nttdata.simulation;

public class Bus extends Vehicle {
	private String busNumber;
	private String busName;
	private double busPrice;
	private String busColor;
	private int maximumSpeed;
	Engine engine;
	
	
	public Bus(String busNumber, String busName, double busPrice, String busColor, int maximumSpeed) {
		super();
		this.busNumber = busNumber;
		this.busName = busName;
		this.busPrice = busPrice;
		this.busColor = busColor;
		this.maximumSpeed = maximumSpeed;
	}


	public String getBusNumber() {
		return busNumber;
	}


	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}


	public String getBusName() {
		return busName;
	}


	public void setBusName(String busName) {
		this.busName = busName;
	}


	public double getBusPrice() {
		return busPrice;
	}


	public void setBusPrice(double busPrice) {
		this.busPrice = busPrice;
	}


	public String getBusColor() {
		return busColor;
	}


	public void setBusColor(String busColor) {
		this.busColor = busColor;
	}


	public int getMaximumSpeed() {
		return maximumSpeed;
	}


	public void setMaximumSpeed(int maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}


	public Engine getEngine() {
		return engine;
	}


	public void setEngine(Engine engine) {
		this.engine = engine;
	}


	void display() {
		System.out.println("bus Number: "+busNumber+"\nbus Name: "+busName+"\nbus Price: "+busPrice+"\nbus Color: "+busColor+"\nMaximum Speed :"+maximumSpeed);
		
	}
	
}
