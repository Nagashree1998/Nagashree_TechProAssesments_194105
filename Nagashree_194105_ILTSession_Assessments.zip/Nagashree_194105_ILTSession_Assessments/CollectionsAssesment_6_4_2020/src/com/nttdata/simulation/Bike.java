package com.nttdata.simulation;

public class Bike extends Vehicle {
	
	private String bikerNumber;
	private String bikeName;
	private double bikePrice;
	private String bikeColor;
	private int maximumSpeed;
	Engine engine;
	public String getBikerNumber() {
		return bikerNumber;
	}
	public void setBikerNumber(String bikerNumber) {
		this.bikerNumber = bikerNumber;
	}
	public String getBikeName() {
		return bikeName;
	}
	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}
	public double getBikePrice() {
		return bikePrice;
	}
	public void setBikePrice(double bikePrice) {
		this.bikePrice = bikePrice;
	}
	public String getBikeColor() {
		return bikeColor;
	}
	public void setBikeColor(String bikeColor) {
		this.bikeColor = bikeColor;
	}
	public int getMaximumSpeed() {
		return maximumSpeed;
	}
	public void setMaximumSpeed(int maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}
	public Engine getEngine() {
		return engine;
	}
	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	public Bike(String bikerNumber, String bikeName, double bikePrice, String bikeColor, int maximumSpeed) {
		super();
		this.bikerNumber = bikerNumber;
		this.bikeName = bikeName;
		this.bikePrice = bikePrice;
		this.bikeColor = bikeColor;
		this.maximumSpeed = maximumSpeed;
	}
	void display() {
		System.out.println("bike Number: "+bikerNumber+"\nbike Name: "+bikeName+"\nbike Price: "+bikePrice+"\nbike Color: "+bikeColor+"\nMaximum Speed :"+maximumSpeed);
		
	}
}
