package com.nttdata.simulation;

public abstract  class Vehicle extends Engine {
	 Engine engine;
	 abstract void display();
	 
}
