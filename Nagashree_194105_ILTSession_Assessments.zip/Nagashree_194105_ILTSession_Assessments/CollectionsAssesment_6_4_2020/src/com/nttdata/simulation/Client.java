package com.nttdata.simulation;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);

		int choice;
		
		System.out.println("Welcome to Vehicle Shop............!!!!!!");
		System.out.println("Press the below keys for more details");
		System.out.println("1. Car\t2. Bike\t3. Bus\t4. Quit");
		choice=scanner.nextInt();
		while(choice!=4){
	
		System.out.println("Enter Vehicle Number");
		String number=scanner.next();
		System.out.println("Enter Vehicle Name");
		String name=scanner.next();
		System.out.println("Enter the Price ");
		double price=scanner.nextDouble();
		System.out.println("Enter the color");
		String color=scanner.next();
		System.out.println("Enter the Maximum Speed");
		int speed=scanner.nextInt();
		switch(choice)
		{
		case 1 : Vehicle car=new Car(number,name,price,color,speed);
						System.out.println("\nDetails are............\n");
						car.display();
						System.out.println("press 1. Start 2.stop 3. Quit");
						int option=scanner.nextInt();
						System.out.print("Car ");
						switch(option){
						case 1 :car.engine=new Engine().start();
									break;
						case 2 : car.engine=new Engine().stop();
									break;
						default : System.out.println("Exit");
									break;
						}
					break;
		case 2 : 	Vehicle bike=new  Bike(number,name,price,color,speed);
					System.out.println("\nDetails are............\n");
					bike.display();
					System.out.println("press 1. Start 2.stop 3. Quit");
					int option1=scanner.nextInt();
					System.out.print("Bike ");
					switch(option1){
						case 1 : bike.engine=new Engine().start();
								break;
						case 2 :bike.engine=new Engine().stop();
								break;
						default : System.out.println("Exit");
								break;
					}
						break;		
						
		case 3 : 	Vehicle bus=new  Bus(number,name,price,color,speed);
					System.out.println("\nDetails are............\n");
					bus.display();
					System.out.println("press 1. Start 2.stop 3. Quit");
					int option2=scanner.nextInt();
					System.out.print("Bus ");
					switch(option2){
					case 1 : bus.engine=new Engine().start();
							break;
					case 2 : bus.engine=new Engine().stop();
							break;
					default : System.out.println("Exit");
							break;
					}
					break;	
					
		}	
		
		System.out.println("Press the below keys for more details");
		System.out.println("1. Car\t2. Bike\t3. Bus\t4. Quit");
		choice=scanner.nextInt();
		
		}
		
		System.out.println("Thank You");
		scanner.close();
	}

}
