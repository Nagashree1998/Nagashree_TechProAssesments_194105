package com.nttdata.collections;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Client {

	public static void main(String[] args) {
		
		Set<Employee> set=new TreeSet<Employee>();
		
		Scanner scanner= new Scanner(System.in);
		int choice;
		do{
		System.out.println("Enter Employee Id");
		int empId=scanner.nextInt();
		
		System.out.println("Enter Employee Name");
		String empName=scanner.next();
		System.out.println("Enter Employee Address");
		String empAddress=scanner.next();
		System.out.println("Enter Employee Salary");
		double empSalary=scanner.nextDouble();
		System.out.println("Enter Employee Grade");
		String empGrade=scanner.next();
		System.out.println("Enter Employee Mobile Number");
		double empPhono=scanner.nextDouble();
		System.out.println("Enter Employee Email Id");
		String empEmail=scanner.next();
		System.out.println("Employee details added successfully");
		set.add(new Employee(empId,empName,empAddress,empSalary,empGrade,empPhono,empEmail));
		
		System.out.println("Press 0 to Stop Adding and Display or any other number to Continue");
		choice=scanner.nextInt();
		}while(choice!=0);
		Iterator<Employee> itr=set.iterator();
		
		while(itr.hasNext()){
			System.out.println(itr.next());
		}

		scanner.close();
		
	}

}
