package com.nttdata.collections;

public class Employee implements Comparable <Employee> {
	private int employeeId;
	private String employeeName;
	private String employeeAddress;
	private double employeeSalary;
	private String employeeGrade;
	private double phoneNumber;
	private String employeeEmail;
	
	public Employee(int employeeId, String employeeName, String employeeAddress, double employeeSalary,
			String employeeGrade, double phoneNumber, String employeeEmail) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeeSalary = employeeSalary;
		this.employeeGrade = employeeGrade;
		this.phoneNumber = phoneNumber;
		this.employeeEmail = employeeEmail;
	}

	@Override
	public int compareTo(Employee e) {
		
		 if(employeeId>e.employeeId){  
		        return 1;  
		    }else if(employeeId<e.employeeId){  
		        return -1;  
		    }else{  
		    	return 0;  
		    }  
	}

	@Override
	public String toString() {
		return "EmployeeId=" + employeeId + ", EmployeeName=" + employeeName + ", EmployeeAddress="
				+ employeeAddress + ", employeeSalary=" + employeeSalary + ", employeeGrade=" + employeeGrade
				+ ", phoneNumber=" + phoneNumber + ", employeeEmail=" + employeeEmail + "";
	}
	
	
	

}
