Delimiter //
Create Procedure selectdetails()
BEGIN
Select * from student;
END//

call selectdetails();

insert into student values(10,"anu",25);
