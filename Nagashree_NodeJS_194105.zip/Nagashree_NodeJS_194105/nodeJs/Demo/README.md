# codemix-vanilla-react
Template for project creation of React inside CodeMix

## Contents

The template project is just an example Hello World that guide you through the use of React with the Expressjs framework to build a very simple web application that display the Hello World!!! Greeting
